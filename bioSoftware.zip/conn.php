<?php
$secure="http";
$domain="localhost";
$lDomain="/bioComplaint";

$hostname="localhost";
$username="root";
$db_password="";
$db_name="biocomplaint";

$conn=mysqli_connect($hostname,$username,$db_password,$db_name);

?>